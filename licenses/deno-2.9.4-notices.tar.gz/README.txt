Deno 2.9.4 conservative notice evidence

Original notice bytes and exact-source provenance are retained.
This bundle is a repository/lockfile superset, not an exact linked-code inventory.
Source archives are separate; their exact URLs and hashes are in deno-notice-index.json.
Review remaining_gaps and native dependency source records.
Third-party source and notices retain their own terms, not Momokun PolyForm restrictions.
